﻿namespace Exam.Entities
{
    public class Banca
    {
        public string Id { get; set; }
        public string Nume { get; set; }
        public double Dobanda { get; set; }
        //public string Tip_credit { get; set; }

        public Adresa Adresa { get; set; }  
        public List<Client> Clienti { get; set; }

        public Banca(string id, string nume, double dobanda, Adresa adresa, List<Client> clienti)
        {
            Id = id;
            Nume = nume;
            Dobanda = dobanda;
            Adresa = adresa;
            Clienti = clienti;
            //Tip_credit = credit;
        }

    }
}
