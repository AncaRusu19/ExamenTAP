﻿using System.Collections.Generic;

namespace Exam.Entities
{
    public static class Stocare
    {
        private static readonly List<Banca> _banci = new List<Banca>();

        static Stocare()
        {
            
            var adresaBanca1 = new Adresa { Id = "1", Strada = "Strada Banca 1", Numar = 1, Apartament = 10 };
            var clientiBanca1 = new List<Client>
            {
                new Client("1", "Ion", "Popescu", new DateOnly(1980, 1, 1), "Credit Ipotecar", new Adresa { Id = "1", Strada = "Strada Client 1", Numar = 1, Apartament = 1 },"credit1"),
                new Client("2", "Maria", "Ionescu", new DateOnly(1990, 2, 2), "Credit Auto", new Adresa { Id = "2", Strada = "Strada Client 2", Numar = 2, Apartament = 2 },"credit2")
            };
            var banca1 = new Banca("1", "Banca 1", 3.5, adresaBanca1, clientiBanca1);

            var adresaBanca2 = new Adresa { Id = "2", Strada = "Strada Banca 2", Numar = 2, Apartament = 20 };
            var clientiBanca2 = new List<Client>
            {
                new Client("3", "George", "Marin", new DateOnly(1975, 3, 3), "Credit Personal", new Adresa { Id = "3", Strada = "Strada Client 3", Numar = 3, Apartament = 3 },"credit1"),
                new Client("4", "Ana", "Georgescu", new DateOnly(1985, 4, 4), "Credit de Nevoi Personale", new Adresa { Id = "4", Strada = "Strada Client 4", Numar = 4, Apartament = 4 },"credit2")
            };
            var banca2 = new Banca("2", "Banca 2", 4.0, adresaBanca2, clientiBanca2);

            _banci.Add(banca1);
            _banci.Add(banca2);
        }

        public static List<Banca> GetBanci()
        {
            return _banci;
        }

        public static Banca GetBancaById(string id)
        {
            return _banci.Find(b => b.Id == id);
        }

        public static void AddBanca(Banca banca)
        {
            _banci.Add(banca);
        }

        public static void ClearBanci()
        {
            _banci.Clear();
        }
    }
}
