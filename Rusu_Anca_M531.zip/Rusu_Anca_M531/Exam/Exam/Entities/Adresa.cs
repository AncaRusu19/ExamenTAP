﻿using System.Diagnostics.Contracts;

namespace Exam.Entities
{
    public class Adresa
    {
        public string Id { get; set; }
        public string Strada { get; set; }
        public int Numar { get; set; }
        public int Apartament { get; set; }

        
    }
}
