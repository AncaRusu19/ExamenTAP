﻿namespace Exam.Entities
{
    public class Client
    {
        public string Id { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public DateOnly Data_nasterii { get; set; }
        public string Tip_credit { get; set; }
        public Adresa Adresa { get; set; }
        public string Credit { get; set; }

        public Client(string id, string nume, string prenume, DateOnly dataNasterii, string tipCredit, Adresa adresa,string credit)
        {
            Id = id;
            Nume = nume;
            Prenume = prenume;
            Data_nasterii = dataNasterii;
            Tip_credit = tipCredit;
            Adresa = adresa;
            Credit = credit;
        }


    }
}
