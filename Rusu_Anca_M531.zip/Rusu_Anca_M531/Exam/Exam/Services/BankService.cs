﻿using System;
using System.Collections.Generic;
using System.Linq;
using Exam.Entities;
using Exam.Services.Contracts;

namespace Exam.Services
{
    public class BankService: IBankService
    {
        public void AddClient(string idBanca, Client client)
        {
            var banca = Stocare.GetBancaById(idBanca);
            if (banca != null)
            {
                banca.Clienti.Add(client);
            }
        }

        public void RemoveClient(string idBanca, string idClient)
        {
            var banca = Stocare.GetBancaById(idBanca);
            if (banca != null)
            {
                var client = banca.Clienti.FirstOrDefault(c => c.Id == idClient);
                if (client != null)
                {
                    banca.Clienti.Remove(client);
                }
            }
        }

        public void UpdateData(string idBanca, Client clientActualizat)
        {
            var banca = Stocare.GetBancaById(idBanca);
            if (banca != null)
            {
                var client = banca.Clienti.FirstOrDefault(c => c.Id == clientActualizat.Id);
                if (client != null)
                {
                    client.Nume = clientActualizat.Nume;
                    client.Prenume = clientActualizat.Prenume;
                    client.Data_nasterii = clientActualizat.Data_nasterii;
                    client.Tip_credit = clientActualizat.Tip_credit;
                    client.Adresa = clientActualizat.Adresa;
                }
            }
        }

        public List<Client> DisplayClient(string idBanca)
        {
            var banca = Stocare.GetBancaById(idBanca);
            return banca?.Clienti ?? new List<Client>();
        }

        public List<Client> FilterClients(string idBanca, string nume, string strada, string tipCredit)
        {
            var banca = Stocare.GetBancaById(idBanca);
            if (banca == null) return new List<Client>();

            var clientiFiltrati = banca.Clienti.Where(c =>
                (string.IsNullOrEmpty(nume) || c.Nume.Contains(nume)) &&
                (string.IsNullOrEmpty(strada) || c.Adresa.Strada.Contains(strada)) &&
                (string.IsNullOrEmpty(tipCredit) || c.Tip_credit.Contains(tipCredit))
            ).ToList();

            return clientiFiltrati;
        }
    }
}
