﻿using System.Linq;
using Exam.Entities;
using Exam.Services.Contracts;

namespace Exam.Services
{
    public class GeneralService: IGeneralService
    {
        private readonly BankService _bankService;

        public GeneralService(BankService bankService)
        {
            _bankService = bankService;
        }

        public void MoveClient(string idBancaSursa, string idBancaDestinatie, string idClient)
        {
            var bancaSursa = Stocare.GetBancaById(idBancaSursa);
            var bancaDestinatie = Stocare.GetBancaById(idBancaDestinatie);

            if (bancaSursa == null || bancaDestinatie == null) return;

            var client = bancaSursa.Clienti.FirstOrDefault(c => c.Id == idClient);
            if (client != null)
            {
                bancaSursa.Clienti.Remove(client);
                bancaDestinatie.Clienti.Add(client);
            }
        }

        public bool SameClient(string idBanca, Client clientComparat)
        {
            var banca = Stocare.GetBancaById(idBanca);
            if (banca == null) return false;

            return banca.Clienti.Any(c => c.Id == clientComparat.Id &&
                                           c.Nume == clientComparat.Nume &&
                                           c.Prenume == clientComparat.Prenume &&
                                           c.Data_nasterii == clientComparat.Data_nasterii &&
                                           c.Tip_credit == clientComparat.Tip_credit &&
                                           c.Adresa.Id == clientComparat.Adresa.Id &&
                                           c.Adresa.Strada == clientComparat.Adresa.Strada &&
                                           c.Adresa.Numar == clientComparat.Adresa.Numar &&
                                           c.Adresa.Apartament == clientComparat.Adresa.Apartament);
        }
    }
}
