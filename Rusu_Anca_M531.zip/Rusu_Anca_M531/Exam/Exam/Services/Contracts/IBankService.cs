﻿using Exam.Entities;

namespace Exam.Services.Contracts
{
    public interface IBankService
    {
        public void AddClient(string idBanca, Client client);
        public void RemoveClient(string idBanca, string idClient);
        public void UpdateData(string idBanca, Client clientActualizat);
        public List<Client> DisplayClient(string idBanca);
       
        public List<Client> FilterClients(string idBanca, string nume, string strada, string tipCredit);
    }
}
