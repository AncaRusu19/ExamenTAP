﻿using Exam.Entities;

namespace Exam.Services.Contracts
{
    public interface IGeneralService
    {
        public void MoveClient(string idBancaSursa, string idBancaDestinatie, string idClient);
        public bool SameClient(string idBanca, Client clientComparat);
    }
}
