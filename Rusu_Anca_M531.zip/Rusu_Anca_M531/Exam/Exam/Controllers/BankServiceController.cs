﻿using Exam.Entities;
using Exam.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Exam.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankServiceController : ControllerBase
    {
        private readonly BankService _bankService;

        public BankServiceController(BankService bankService)
        {
            _bankService = bankService;
        }

        [HttpPost("{idBanca}/clienti")]
        public IActionResult AdaugaClient(string idBanca, [FromBody] Client client)
        {
            _bankService.AddClient(idBanca, client);
            return Ok();
        }

        [HttpDelete("{idBanca}/clienti/{idClient}")]
        public IActionResult StergeClient(string idBanca, string idClient)
        {
            _bankService.RemoveClient(idBanca, idClient);
            return Ok();
        }

        [HttpPut("{idBanca}/clienti")]
        public IActionResult ActualizeazaClient(string idBanca, [FromBody] Client client)
        {
            _bankService.UpdateData(idBanca, client);
            return Ok();
        }

        [HttpGet("{idBanca}/clienti")]
        public IActionResult AfiseazaClienti(string idBanca)
        {
            var clienti = _bankService.DisplayClient(idBanca);
            return Ok(clienti);
        }

        [HttpGet("{idBanca}/clienti/filtreaza")]
        public IActionResult FiltreazaClienti(string idBanca, [FromQuery] string nume, [FromQuery] string strada, [FromQuery] string tipCredit)
        {
            var clienti = _bankService.FilterClients(idBanca, nume, strada, tipCredit);
            return Ok(clienti);
        }
    }
}
