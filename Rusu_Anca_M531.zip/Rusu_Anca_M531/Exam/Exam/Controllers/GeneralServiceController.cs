﻿using Exam.Entities;
using Exam.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Exam.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GeneralServiceController : ControllerBase
    {
        private readonly GeneralService _generalService;

        public GeneralServiceController(GeneralService generalService)
        {
            _generalService = generalService;
        }

        [HttpPost("mutaClient")]
        public IActionResult MoveClient([FromQuery] string idBancaSursa, [FromQuery] string idBancaDestinatie, [FromQuery] string idClient)
        {
            _generalService.MoveClient(idBancaSursa, idBancaDestinatie, idClient);
            return Ok();
        }

        [HttpPost("esteAcelasiClient")]
        public IActionResult SameClient([FromQuery] string idBanca, [FromBody] Client client)
        {
            var rezultat = _generalService.SameClient(idBanca, client);
            return Ok(rezultat);
        }
    }
}
